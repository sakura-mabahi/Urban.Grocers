URL_SERVICE = "https://d23f8d2b-5d37-4f7b-b19d-56112b1daf0e.serverhub.tripleten-services.com" # Insertar dirección de URL del servidor
DOC_PATH = "/docs/" # Almacena la ruta específica para acceder a la documentación en la URL base.
LOG_MAIN_PATH = "/api/logs/main/"
USERS_TABLE_PATH = "/api/db/resources/user_model.csv"
CREATE_USER_PATH = "/api/v1/users/" # Almacena la ruta para crear un usuario o usuaria en esta variable
KITS_PATH = "/api/v1/kits/" # Almacena la ruta para crear un kit en esta variable
